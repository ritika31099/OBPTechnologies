<?php include 'include/header.php';?>
<?php include 'include/menu.php';?>
<div class="container-fluid aboutus2  Young">
	<h2 class="text-center text-white Young1 "><strong>About Us</strong></h2>
	<p class="text-center text-white"><b>Home</b> / Director's Message</p>
</div>
<div class="container py-4">
	<div class="row">
		<div class="col-md-4">
			<div class="director-section">
			 <img src="img/director.jpeg" alt="#"class="img-fluid img-thumbnail">
			</div>
		</div>	
		<div class="col-md-8 community">
			<h2 class="  ourteach">Director's Message</h2>
			<p> My aim behind this playschool is to provide basic education to the unprivileged children of our society. My childhood was simple and poor. My childhood taught me the importance of money. That money became a huge boundary between me and education. I crossed that barrier through my hard work and zeal to become successful in life. 
			Today when I come across parents facing difficulty in paying fees of the schools, I feel the importance of introducing playschools for early child development.
			Little Tree School is all about our children of society. I have established an institution for you to let the burden on our shoulders. Education is for all and above all.
			</p>
		</div>
	</div>
</div>
<!-- ================ -->
<?php include 'include/footer.php';?>