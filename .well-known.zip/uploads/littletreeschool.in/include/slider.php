<div class="container-fluid px-0">
  <div class="bd-example">
    <div id="carouselExampleCaptions" class="carousel slide my-slider" data-ride="carousel">
      <!-- <ol class="carousel-indicators">
        <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
        <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
      </ol> -->
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="img/slider/slide1.jpeg" class="w-100">
          <div class="carousel-caption">
            <!-- <div class="appoint blink-text">
              <a href="career-niks-technology-in-patna.php">Appointment</a>
            </div> -->
          </div>
        </div>
        <div class="carousel-item">
          <img src="img/slider/slide2.jpeg" class="w-100">
          <div class="carousel-caption">
            <!-- <div class="appoint blink-text">
              <a href="career-niks-technology-in-patna.php">Appointment</a>
            </div> -->
          </div>
        </div>
        <!-- <div class="carousel-item">
          <img src="img/school3.jpg" class=" w-100" alt="...">
          <div class="carousel-caption d-none d-md-block">
            
          </div>
        </div> -->
      </div>
      <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
        <i class="fa fa-chevron-circle-left slider-left" aria-hidden="true"></i>
        <span class="sr-only">Previous</span>
      </a>
      <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
        <i class="fa fa-chevron-circle-right slider-right" aria-hidden="true"></i>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
  <!-- ================================================================================= -->
</div>