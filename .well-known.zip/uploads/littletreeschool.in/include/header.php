<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->

  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/style.css">
   <link rel="stylesheet" href="css/responsive.css">  
  <link rel="stylesheet" href="css/slick.css"> 
  <link rel="stylesheet" href="css/slick-theme.css">
   <link rel="stylesheet" href="css/touchTouch.css"> 
  <link rel="stylesheet" href="css/jQuery-plugin-progressbar.css">  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
   <!--  <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet"> -->
   <!--  <link href="css/custom.css" rel="stylesheet"> -->
  <!-- <script src="js/vendor/modernizr-3.7.1.min.js"></script> -->
 <!--  <script src="js/jquery.min.js"></script>
   -->
  <script src="js/jQuery-plugin-progressbar.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
</head>

<body>
<div class="icon-bar">
  <a href="#" class="facebook"><i class="fab fa-facebook"></i></a>
  <a href="#" class="twitter"><i class="fab fa-twitter"></i></a>
  <a href="#" class="google"><i class="fab fa-instagram"></i></a>
  <a href="#" class="linkedin"><i class="fab fa-linkedin-in"></i></a>
  <a href="#" class="youtube"><i class="fab fa-youtube-square"></i></a>
</div>
<div class="appoint blink-text">
      <a href="#">Admission Free<br>For 1 month</a>
    </div>
  <!-- start header -->
  