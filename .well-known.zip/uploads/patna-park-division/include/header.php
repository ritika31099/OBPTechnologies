<!DOCTYPE html>
<html lang="en">
<!-- head -->

<head>

    <meta name="theme-color" content="#43B14B" />
    <meta name="viewport" content="width=device-width,initial-scale=1.0" />
    <title>Patna Park Division</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/animate.min.css" rel="stylesheet" type="text/css">
    <link href="css/menuzord-megamenu.css" rel="stylesheet" />
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="font/flaticon.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <link href="css/responsive.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" />
    <link rel="stylesheet" href="css/owl.theme.default.min.css" />
    <script src="js/jquery-2.2.4.min.js"></script>

</head>
<body>