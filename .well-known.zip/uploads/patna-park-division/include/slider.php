<!-- Slider -->
<section id="section-1">
        <div class="content-slider">
            <input type="radio" id="banner1" class="sec-1-input" name="banner" checked>
            <input type="radio" id="banner2" class="sec-1-input" name="banner">
            <input type="radio" id="banner3" class="sec-1-input" name="banner">
            <input type="radio" id="banner4" class="sec-1-input" name="banner">
            <div class="slider">
                <div id="top-banner-1" class="banner">
                    <div class="banner-inner-wrapper">
                        <!--<h2>Creative Template</h2>
                        <h1>Welcome<br>to MoGo</h1>
                        <div class="learn-more-button"><a href="#section-2">Learn More</a></div>-->
                    </div>
                </div>
                <div id="top-banner-2" class="banner">
                    <div class="banner-inner-wrapper">
                        <!--<h2>Creative Template</h2>
                        <h1>Welcome<br>to MoGo</h1>
                        <div class="learn-more-button"><a href="#section-2">Learn More</a></div>-->
                    </div>
                </div>
                <div id="top-banner-3" class="banner">
                    <div class="banner-inner-wrapper">
                        <!--<h2>Creative Template</h2>
                        <h1>Welcome<br>to MoGo</h1>
                        <div class="learn-more-button"><a href="#section-2">Learn More</a></div>-->
                    </div>
                </div>
                <div id="top-banner-4" class="banner">
                    <div class="banner-inner-wrapper">
                        <!--<h2>Creative Template</h2>
                        <h1>Welcome<br>to MoGo</h1>
                        <div class="learn-more-button"><a href="#section-2">Learn More</a></div>-->
                    </div>
                </div>
            </div>
            <nav>
                <div class="controls">
                    <label for="banner1"><span class="progressbar"><span class="progressbar-fill"></span></span><span></span> Park View </label>
                    <label for="banner2"><span class="progressbar"><span class="progressbar-fill"></span></span><span></span> Park's Flower </label>
                    <label for="banner3"><span class="progressbar"><span class="progressbar-fill"></span></span><span></span> MIG 21 </label>
                    <label for="banner4"><span class="progressbar"><span class="progressbar-fill"></span></span><span></span> Guru Vatika </label>
                </div>
            </nav>
        </div>
    </section>
    <!-- Slider -->