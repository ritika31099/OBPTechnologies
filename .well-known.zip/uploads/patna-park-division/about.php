<?php include("include/header.php"); ?>
<?php include("include/menu.php"); ?>
<section class="banner-section">
  <img src="img/banner-park.jpg" class="img-fluid" alt="">
  <div class="shadow-img">

  </div>
</section>
<section class="bg-gray inner-page-section">
  <div class="container">
    <div class="inner-content-section">
      <div class="col-md-4">
        <div class="about-img">
          <img src="img/about.jpeg" alt="about-img">
        </div>
      </div>
      <div class="col-md-8">
        <div class="about-content">
            <h1>About Patna Park Division</h1>
            <div class="inner-content-main">
            <p>The main objective of the park development in the Patna is to increase the green cover in this highly polluted city so as to check the adverse effects of different kinds of pollution, to provide a recreational venue for the visitors to spend their leisure time.</p>
            <p>The main objective of the park development in the Patna is to increase the green cover in this highly polluted city so as to check the adverse effects of different kinds of pollution, to provide a recreational venue for the visitors to spend their leisure time.</p>
            <p>The main objective of the park development in the Patna is to increase the green cover in this highly polluted city so as to check the adverse effects of different kinds of pollution, to provide a recreational venue for the visitors to spend their leisure time.</p>
            </div>
        </div>
      </div>
    </div>
  </div>

</section>
<?php include("include/footer.php"); ?>