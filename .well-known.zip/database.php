<?php
$con = mysqli_connect('localhost:3306','obptechn_obp','obptech@12345','obptechn_obp_db')
?>